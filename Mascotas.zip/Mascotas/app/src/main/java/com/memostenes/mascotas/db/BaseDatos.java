package com.memostenes.mascotas.db;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.view.View;

import com.memostenes.mascotas.pojo.Mascota;

import java.util.ArrayList;

/**
 * Created by memo on 5/09/16.
 */
public class BaseDatos extends SQLiteOpenHelper {
    private Context context;

    public BaseDatos(Context context) {
        super(context, ConstantesBaseDatos.DATABASE_NAME, null, ConstantesBaseDatos.DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String queryCrearTablaMascota = "CREATE TABLE " + ConstantesBaseDatos.TABLE_MASCOTAS
                + "(" + ConstantesBaseDatos.TABLE_MASCOTAS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE + " TEXT, " + ConstantesBaseDatos.TABLE_MASCOTAS_FOTO + " INTEGER )";
        db.execSQL(queryCrearTablaMascota);
        String queryCrearTablaLikesMascotas = "CREATE TABLE " + ConstantesBaseDatos.TABLE_LIKES_MASCOTA +
                "(" + ConstantesBaseDatos.TABLE_MASCOTAS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + ConstantesBaseDatos.TABLE_LIKES_MASCOTA_ID_MASCOTA + " INTEGER, " + ConstantesBaseDatos.TABLE_MASCOTAS_LIKES
                + " INTEGER, FOREIGN KEY (" + ConstantesBaseDatos.TABLE_MASCOTAS_ID + ") REFERENCES " + ConstantesBaseDatos.TABLE_MASCOTAS
                + "(" + ConstantesBaseDatos.TABLE_MASCOTAS_ID + "))";
        db.execSQL(queryCrearTablaLikesMascotas);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXIST " + ConstantesBaseDatos.TABLE_MASCOTAS);
        db.execSQL("DROP TABLE IF EXIST " + ConstantesBaseDatos.TABLE_LIKES_MASCOTA);
        onCreate(db);
    }

    public ArrayList<Mascota> obtenerMascotas() {
        ArrayList<Mascota> mascotas = new ArrayList<>();
        String inst = "SELECT * FROM mascota";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor registros = db.rawQuery(inst, null);
        while (registros.moveToNext()) {
            Mascota actual = new Mascota();
            actual.setID(registros.getInt(0));
            actual.setNombre(registros.getString(1));
            actual.setFoto(registros.getInt(2));
            String inst2 = "SELECT COUNT (likes) FROM mascota_like WHERE id_mascota = " + actual.getId();
            Cursor registrosLikes = db.rawQuery(inst2, null);
            if (registrosLikes.moveToNext()) {
                actual.setLikes(registrosLikes.getInt(0));
            } else {
                actual.setLikes(0);
            }
            mascotas.add(actual);
        }
        db.close();

        return mascotas;
    }

    public void insertarMascota(ContentValues contentValues) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(ConstantesBaseDatos.TABLE_MASCOTAS, null, contentValues);
        db.close();
    }

    public void insertarLikeMascota(ContentValues contentValues) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(ConstantesBaseDatos.TABLE_LIKES_MASCOTA, null, contentValues);
        db.close();
    }

    public int obtenerLikesMascota(Mascota mascota) {
        int likes = 0;
        String inst = "SELECT COUNT(likes) FROM " + ConstantesBaseDatos.TABLE_LIKES_MASCOTA
                + " WHERE id_mascota=" + mascota.getId();
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor registros = db.rawQuery(inst, null);
        if (registros.moveToNext()) {
            likes = registros.getInt(0);
        }
        db.close();
        return likes;
    }
}

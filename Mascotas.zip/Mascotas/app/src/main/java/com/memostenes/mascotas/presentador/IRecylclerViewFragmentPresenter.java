package com.memostenes.mascotas.presentador;

/**
 * Created by memo on 5/09/16.
 */
public interface IRecylclerViewFragmentPresenter {
    public void obtenerMascotasBaseDatos();
    public void mostrarMascotasRV();
}

package com.memostenes.mascotas;

/**
 * Created by memo on 4/07/16.
 */
public class Config {
    public static final String EMAIL = "";  //colocar datos de cuenta de gmail aqui
    public static final String PASSWORD = "";
}

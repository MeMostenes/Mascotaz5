package com.memostenes.mascotas.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.memostenes.mascotas.Favoritas;
import com.memostenes.mascotas.R;
import com.memostenes.mascotas.adapter.MascotaAdaptador;
import com.memostenes.mascotas.pojo.Mascota;
import com.memostenes.mascotas.presentador.IRecylclerViewFragmentPresenter;
import com.memostenes.mascotas.presentador.RecyclerViewFragmentPresenter;

import java.util.ArrayList;

/**
 * Created by memo on 5/07/16.
 */
public class ReciclerViewFragment  extends Fragment implements IRecyclerViewFragmentView {
    ArrayList<Mascota> mascotas;
    private RecyclerView listaMascotas;
    private IRecylclerViewFragmentPresenter presenter;
    @Nullable
    @Override

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //return super.onCreateView(inflater, container, savedInstanceState);
        Button btnEstrella = (Button) getActivity().findViewById(R.id.btEstrella);
        btnEstrella.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), Favoritas.class);
                // intent.putExtra("mascotass", (Parcelable) mascotas.get(0));

                //intent.putExtra("te", m);
                /*
                //ORDENAR LOS LIKES PARA EN LA SIGUIENTE VENTANA SOLO MOSTRAR LOS 5 MAS LIKEADOS
                int likes[]= new int[10];
                for (int i=0; i<mascotas.size(); i++){
                    likes[i] = mascotas.get(i).getLikes();
                    // Log.i("likes", String.valueOf(likes[i]));
                    // System.out.println(likes[i]);
                }
                int actual=0;
                int may;
                int mayores[] = new int[5];
                for (int vu=1; vu<=5; vu++){
                    may = actual;
                    for(int i=0; i<10; i++ ){
                        if(likes[may]<likes[i]){
                            may=i;
                        }
                    }
                    mayores[actual]=may;
                    System.out.println(mayores[actual]);
                    likes[may]=-1;

                    actual++;
                }

                intent.putExtra("uno", mascotas.get(mayores[0]));
                intent.putExtra("dos", mascotas.get(mayores[1]));
                intent.putExtra("tres", mascotas.get(mayores[2]));
                intent.putExtra("cuatro", mascotas.get(mayores[3]));
                intent.putExtra("cinco", mascotas.get(mayores[4]));
                */

                startActivity(intent);
            }
        });

        View v = inflater.inflate(R.layout.fragment_reciclerview, container,false);
        listaMascotas = (RecyclerView) v.findViewById(R.id.rvMascotas);
        /*LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        listaMascotas.setLayoutManager(llm);
        */
        presenter = new RecyclerViewFragmentPresenter(this,getContext());
        return v;
    }

    /*public void inicializarListaMascotas(){
        mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota("Rosco", 0, R.drawable.perro1));
        mascotas.add(new Mascota("Tracy", 0, R.drawable.perro2));
        mascotas.add(new Mascota("Juancho", 0, R.drawable.perro4));
        mascotas.add(new Mascota("Lula", 0, R.drawable.perro5));
        mascotas.add(new Mascota("Chenta", 0, R.drawable.perro3));
        mascotas.add(new Mascota("Tayson", 0, R.drawable.perro6));
        mascotas.add(new Mascota("Fido", 0, R.drawable.perro7));
        mascotas.add(new Mascota("Lasy", 0, R.drawable.perro8));
        mascotas.add(new Mascota("Wero", 0, R.drawable.perro9));
        mascotas.add(new Mascota("Greñas", 0, R.drawable.perro10));
    }
*/

    @Override
    public void generarLinearLayoutVertical() {
        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        listaMascotas.setLayoutManager(llm);
    }

    @Override
    public MascotaAdaptador crearAdaptador(ArrayList<Mascota> mascotas) {
        MascotaAdaptador adaptador = new MascotaAdaptador(mascotas, getActivity());
        return adaptador;
    }

    @Override
    public void inicializarAdaptadorRV(MascotaAdaptador adaptador) {
        listaMascotas.setAdapter(adaptador);
    }
}

package com.memostenes.mascotas.fragment;

import com.memostenes.mascotas.adapter.MascotaAdaptador;
import com.memostenes.mascotas.pojo.Mascota;

import java.util.ArrayList;

/**
 * Created by memo on 5/09/16.
 */
public interface IRecyclerViewFragmentView {

    public void generarLinearLayoutVertical();

    public MascotaAdaptador crearAdaptador(ArrayList<Mascota> mascotas);

    public void inicializarAdaptadorRV(MascotaAdaptador adaptador);
}

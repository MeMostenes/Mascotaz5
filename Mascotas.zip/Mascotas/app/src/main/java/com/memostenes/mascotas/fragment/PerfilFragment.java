package com.memostenes.mascotas.fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.memostenes.mascotas.R;
import com.memostenes.mascotas.adapter.PerfilAdaptador;
import com.memostenes.mascotas.pojo.Mascota;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class PerfilFragment extends Fragment {
    ArrayList<Mascota> mascotas;
    private RecyclerView listaFotos;

    public PerfilFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_perfil, container,false);
        listaFotos = (RecyclerView) v.findViewById(R.id.rvAlbum);
        /*LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        listaFotos.setLayoutManager(llm);
        */
        GridLayoutManager glm = new GridLayoutManager(getActivity(), 2);
        listaFotos.setLayoutManager(glm);
        inicializarListaFotos();
        inicializarAdaptador();
        return v;
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_perfil, container, false);
    }
    public void inicializarAdaptador(){
        PerfilAdaptador adaptador = new PerfilAdaptador(mascotas, getActivity());
        listaFotos.setAdapter(adaptador);
    }
    public void inicializarListaFotos(){
        mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota("Rosco", 3, R.drawable.perro1));
        mascotas.add(new Mascota("Rosco", 2, R.drawable.perro1));
        mascotas.add(new Mascota("Rosco", 0, R.drawable.perro1));
        mascotas.add(new Mascota("Rosco", 7, R.drawable.perro1));
        mascotas.add(new Mascota("Rosco", 4, R.drawable.perro1));
        mascotas.add(new Mascota("Rosco", 1, R.drawable.perro1));
    }
}

package com.memostenes.mascotas.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.memostenes.mascotas.R;
import com.memostenes.mascotas.pojo.Mascota;

import java.util.ArrayList;

/**
 * Created by memo on 12/07/16.
 */
public class PerfilAdaptador extends RecyclerView.Adapter<PerfilAdaptador.PerfilViewHolder>{
    ArrayList<Mascota> mascotas;
    Activity activity;
    public PerfilAdaptador(ArrayList<Mascota>mascotas, Activity activity){
        this.mascotas=mascotas;
        this.activity = activity;
    }
    @Override
    public PerfilViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_perfil, parent, false);
        return new PerfilViewHolder(v);
    }

    @Override
    public void onBindViewHolder(PerfilViewHolder perfilViewHolder, int position) {
        final Mascota mascota = mascotas.get(position);
        perfilViewHolder.imgFoto.setImageResource(mascota.getFoto());
        perfilViewHolder.tvLikes.setText(String.valueOf(mascota.getLikes()));
    }

    @Override
    public int getItemCount() {
        return mascotas.size();
    }

    public static class PerfilViewHolder extends RecyclerView.ViewHolder{
        private ImageView imgFoto;
        private TextView tvLikes;
        public PerfilViewHolder(View itemView) {
            super(itemView);
            imgFoto = (ImageView) itemView.findViewById(R.id.imgFoto);
            tvLikes = (TextView ) itemView.findViewById(R.id.tvLikes);
        }
    }
}
